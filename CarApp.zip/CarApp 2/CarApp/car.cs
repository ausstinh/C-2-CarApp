﻿namespace CarApp
{
    public class Car
    {
        public string Make { get; set; }
        public string Model { get; set; }
        public decimal Price { get; set; }
        public string Color { get; set; }
        public int Year { get; set; }
        public Car()
        {
            Make = "nothing yet";
            Model = "nothing yet";
            Color = "nothing yet";
            Year = 0;
            Price = 0.00M;

        }

        public Car(string a, string b, string c, int d, decimal e)
        {
            Make = a;
            Model = b;
            Color = c;
            Year = d;
            Price = e;
        }

        override public string ToString()
        {
            return "Make: " + Make + " Model: " + Model + " Color: " + Color + " Year: " + Year + " Price: $" + Price;
        }
    }
}
